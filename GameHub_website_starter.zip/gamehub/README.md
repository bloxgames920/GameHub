# GameHub Starter

A polished, responsive front-end based on the GameHub mockup.

## Run locally
Open `index.html` in a browser. No build step is required.

## Publish
Upload `index.html` to a static host such as GitHub Pages, Cloudflare Pages, Netlify, Vercel, or similar.

## What is included
- Responsive neon/dark GameHub layout
- Sidebar navigation and multiple sections
- Game library with search
- Favorites and recently played state
- Mod manager UI
- AI assistant demo UI
- Music and social sections
- Account demo using browser localStorage
- Mobile responsive layout

## Production upgrades
This is the front-end foundation. For a real public service, connect:
- Authentication: Firebase Auth, Supabase Auth, Auth0, or your own backend
- Database: PostgreSQL/Supabase/Firebase
- Storage/CDN for licensed artwork and user media
- Game metadata API
- YouTube API / OAuth
- Real AI API
- Moderation/reporting tools
- A signed desktop companion app for local game launching and supported mod installation

Important: do not distribute copyrighted game binaries or unlicensed game artwork. For a production catalog, use licensed/official assets and link/launch games the user legally owns.
